
let in2 = document.getElementById('in_1');


console.log(in2.getAttribute('id'))
console.log(in2.getAttribute('value'))
console.log(in2.getAttribute('name'))
console.log(in2.setAttribute('class','input'))
console.log(in2);

$( "#in_1" ).addClass('newClass')