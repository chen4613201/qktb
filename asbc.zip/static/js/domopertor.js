
function toAppendChild(parentElement){
    let argslength = arguments.length;
    for(let i=1;i<argslength;i++){
       parentElement.appendChild(arguments[i]);
    }
}
function toCreateElement(element){
    let eleObj = document.createElement(element);
    return eleObj;
}
function toGetElementById(element){
    let eleObj = document.getElementById(element);
    return eleObj;
}
function toCreateTextNode(elementStr){
    let eleobj = document.createTextNode(elementStr);
    return eleobj;
}
function toSetAttribute(obj){
    let argslength = arguments.length;
    for(let i=1;i<argslength;i=i+2){
       obj.setAttribute(arguments[i],arguments[i+1]);
    }
    return obj;
}
function toRemoveNode(obj){
    let ffobj = obj.parentNode.parentNode;
    let zfobj = obj.parentNode;
    ffobj.removeChild(zfobj);
}


