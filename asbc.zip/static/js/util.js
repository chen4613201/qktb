function addServer(){
    let newin = toAddServerInfo();
    let divItem = toGetElementById('itemDiv')
    toAppendChild(divItem, newin);
     $.get("/addServerItem/remoteConn/",{'a':1,'b':2}, function(ret){
       console.log(ret);
      });
}
function toAddServerInfo(ServerName, ServerPort, Username, Password){
    let divobj = toCreateElement("form");
    let Svr = toAddLabelAndInput('Server Name:', ServerName);
    let Pt = toAddLabelAndInput('Server Port:', ServerPort);
    let Unama = toAddLabelAndInput('Server User:', Username);
    let Pw = toAddLabelAndInput('Server Password:', Password);
    let bt = toCreateElement("input");
    let delbt = toCreateElement("input");
    toSetAttribute(bt, "type" ,"submit", "value" , "modify");
    toSetAttribute(delbt, "type" ,"button", "value" , "delete");
    toAppendChild(divobj, Svr, Pt, Unama, Pw, bt, delbt);
    delbt.addEventListener("click",function(){
        toRemoveNode(this);
    },false);

    //divobj.action.url("ImportExcel1", null, "CommonInfo", "CommonX6Api");
    return divobj;
}
function toAddLabelAndInput(labelName,InputDefaultValue){
    let divobj = toCreateElement("div");
    let labelObj = toCreateElement("label");
    let inputObj = toCreateElement("input");
    let textObj = toCreateTextNode(labelName);
    toAppendChild(labelObj, textObj);
    toSetAttribute(inputObj, "value",InputDefaultValue);
    toAppendChild(divobj, labelObj, inputObj);
    return divobj;
}