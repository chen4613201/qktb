# -*- Encoding:UTF-8 -*-


class MyClass:

    def __init__(self, s='aaa'):
        self.s = s
        print("sdf")
        print(self.__class__)
        print(self.__dict__)
        print(self.__doc__)
        #print(self.__annotations__)
        print(self.__module__)
        #print(self.__slots__)

    def __del__(self):
        print(self.__class__.__name__)


obj = MyClass()
print("==============")
print(obj.s)
obj.__del__()
del obj
print("del obj")
print(obj)

