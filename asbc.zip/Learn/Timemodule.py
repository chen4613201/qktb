# -*- Encoding:UTF-8 -*-
import time
import calendar

print(time.time())

print(time.localtime(time.time()))

print(time.asctime(time.localtime(time.time())))

print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))

print(time.strftime("%Y", time.localtime()))

print(calendar.month(2016, 1))

print(time.timezone)