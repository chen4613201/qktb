# -*- Encoding: UTF-8 -*-
print("complex strings")

print("abc" * 2)

Str = "zxcvbasdf"

print(Str[0:2])

print(Str[1:])

List = ["abc", "cbc", "fds"]

print(List)

List.append("newadd")

print(List)

Tuple = ("adfs", 123)

print(Tuple[0])

dirctory = {"asdf":"sfsf", "sdf":"zxcv", "saf":12313}

print(dirctory["asdf"])
