# -*- coding: UTF-8 -*-

print("你好");
