# -*- Encoding:UTF-8 -*-

if "a"=="b":
    print("a equal b")
elif "a" > "b":
    print("a>b")
else:
    print("a not equal b")
