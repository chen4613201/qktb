#-*- Encoding:UTF-8 -*-

print("please input ")

Ein = input()

print(Ein)

file = open("D:\\3333\\新建文本文档.txt", "r+")


print(file.closed)

print(file.encoding)

print(file.mode)

print(file.name)

print(file.readline())

file.close()
file = open("D:\\3333\\新建文本文档.txt")
while 1:
    lines = file.readlines(100000)
    if not lines:
        break
    for line in lines:
        print(line)
print(file.closed)

file.close()

