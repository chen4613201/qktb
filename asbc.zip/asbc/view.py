from django.shortcuts import render
from django.http import HttpResponse


def get(request):
    return render(request, 'index.html')


def remoteConn(request):
    a = request.GET.get('a', 0)
    b = request.GET.get('b', 0)
    c = int(a) + int(b)
    return HttpResponse(str(c))


def hello(request):
    context = {}
    context['hello'] = 'Hello World!'
    context['request']=request
    return render(request, 'bootstrap.html', context)


def addServerItem(request):
    context = {}
    context['hello'] = 'Hello World!'
    context['name'] = 'chen'
    context['set'] = 'man'
    return render(request, 'index.html', context)


def propandattr(request):
    context = {}
    context['hello'] = 'Hello World!'
    context['name'] = 'chen'
    context['set'] = 'man'
    return render(request, 'jquerypropandattr.html', context)


def pop(request):
    context = {}
    context['hello'] = 'Hello World!'
    context['name'] = 'chen'
    context['set'] = 'man'
    return render(request, 'pop.html', context)


def nowbegin(request):
    context = {}
    context['hello'] = 'Hello World!'
    context['name'] = 'chen'
    context['set'] = 'man'
    return render(request, 'nowbegin.html', context)
